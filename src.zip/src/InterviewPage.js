import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
import './InterviewPage.css'; // Import the CSS file

const INITIAL_COINS = 100; // Define initial coins
const HINT_COST = 20; // Define cost to unlock the hint

export default function GuidedInterviewPage() {
  const [coins, setCoins] = useState(INITIAL_COINS); // Initialize coins state
  const [progress, setProgress] = useState(0); // Initialize progress state
  const [isHintUnlocked, setHintUnlocked] = useState(false); // Initialize state for the hint lock

  const navigate = useNavigate(); // Initialize navigate hook

  const handleUnlock = (cost) => {
    if (coins >= cost) {
      setCoins((prev) => prev - cost); // Deduct coins
      setHintUnlocked(true); // Unlock the hint
    }
  };

  const handleEndInterview = () => {
    navigate('/interview-report'); // Navigate to Interview Report page
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => (prev < 100 ? prev + 1 : 0)); // Simulate progress
    }, 1000);
    return () => clearInterval(timer); // Clean up the timer
  }, []);

  return (
    <div className="interview-page">
      <header className="interview-page-header">
        <h1>Guided Interview</h1>
        <p>Practice your coding skills in a realistic interview environment.</p>
      </header>

      <div className="interview-page-coins-section">
        <div className="interview-page-coins">
          <span>{coins} Coins</span>
          <div className="interview-page-progress-bar">
            <div className="interview-page-progress-value" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
        {/* Attach the handleEndInterview function to this button */}
        <button className="interview-page-button" onClick={handleEndInterview}>
          End Interview
        </button>
      </div>

      <div className="interview-page-grid">
        <div className="space-y-6">
          <div className="interview-page-question-box">
            <h2>Interview Question</h2>
            <p>Implement a function that finds the longest palindromic substring in a given string.</p>
          </div>

          {/* Hint Section */}
          <div className={`interview-page-hint-box ${isHintUnlocked ? 'unlocked' : 'locked'}`}>
            <h3>Hint:</h3>
            {isHintUnlocked ? (
              <p>Consider using dynamic programming to optimize your solution.</p>
            ) : (
              <p className="locked-text">Hint is locked. Spend {HINT_COST} coins to unlock.</p>
            )}
            {!isHintUnlocked && (
              <button
                className="interview-page-button unlock-button"
                onClick={() => handleUnlock(HINT_COST)}
                disabled={coins < HINT_COST}
              >
                Unlock Hint
              </button>
            )}
          </div>

          {/* Lisa AI Interview Section with Video */}
          <div className="interview-page-video-header">Lisa AI Interview</div>
          <div className="interview-page-video-body">
            {/* Video tag with autoplay and loop */}
            <video
              width="100%"
              height="200px"
              controls
              autoPlay
              loop
              className="interview-page-video"
            >
              <source src="/lisa.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>

        {/* Code Editor Section */}
        <div className="interview-page-code-box">
          <h2>Code Editor</h2>
          <pre>
            {`function example() {
  console.log("Hello, world!");
}

// Start coding here...`}
          </pre>
        </div>
      </div>

      {/* Floating Video Box */}
      <div className="interview-page-floating-video">
        <div className="interview-page-floating-video-header">
          Your Video
          <button className="minimize-button">_</button> {/* Minimize button placeholder */}
        </div>
        <div className="interview-page-floating-video-body">
          <span>Video Feed</span>
        </div>
      </div>
    </div>
  );
}
