import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './LoginPage';
import Dashboard from './Dashboard';
import InterviewPage from './InterviewPage'; // Import the Interview Page
import InterviewReport from './InterviewReport'; // Import the InterviewReport page

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/interview" element={<InterviewPage />} /> {/* Interview Page Route */}
        <Route path="/interview-report" element={<InterviewReport />} /> {/* Interview Report Route */}

      </Routes>
    </Router>
  );
}

export default App;
